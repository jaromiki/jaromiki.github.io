#include "resource.h"
#include <stdio.h>
#include <ijl.h>

GLuint texture[3];
int q;
HRSRC hResInfo;
HGLOBAL hglobal;
LPVOID lpvoid;
HMODULE hmodule;
extern BYTE *wscreen;
extern int texture_s;

AUX_RGBImageRec *LoadBMP(char *Filename)				
{
	FILE *File=NULL;									

	if (!Filename)										
	{
		return NULL;									
	}

	File=fopen(Filename,"r");							

	if (File)											
	{
		fclose(File);									
		return auxDIBImageLoad(Filename);				
	}

	return NULL;										
}

BOOL DecodeFromJPEGBuffer(
		BYTE* lpJpgBuffer,
		DWORD dwJpgBufferSize,
		BYTE** lppRgbBuffer,
		DWORD* lpdwWidth,
		DWORD* lpdwHeight,
		DWORD* lpdwNumberOfChannels)
{
	BOOL bres;
	IJLERR jerr;
	DWORD dwWholeImageSize;
	BYTE* lpTemp = NULL;

	JPEG_CORE_PROPERTIES jcprops;
	bres = TRUE;
	__try
	{
		
		jerr = ijlInit(&jcprops);
		if(IJL_OK != jerr)
		{
			bres = FALSE;
			__leave;
		}

		jcprops.JPGFile = NULL;
		jcprops.JPGBytes = lpJpgBuffer;
		jcprops.JPGSizeBytes = dwJpgBufferSize;
		jerr = ijlRead(&jcprops, IJL_JBUFF_READPARAMS);
		if(IJL_OK != jerr)
		{
			bres = FALSE;
			__leave;
		}
		switch(jcprops.JPGChannels)
		{
			case 1:
			{
				jcprops.JPGColor = IJL_G;
				jcprops.DIBColor = IJL_RGB;
				jcprops.DIBChannels = 3;
				break;
			}
			case 3:
			{
				jcprops.JPGColor = IJL_YCBCR;
				jcprops.DIBColor = IJL_RGB;
				jcprops.DIBChannels = 3;
				break;
			}
			default:
			{
				jcprops.JPGColor = IJL_OTHER;
				jcprops.DIBColor = IJL_OTHER;
				jcprops.DIBChannels = jcprops.JPGChannels;
				break;
			}
		}

		dwWholeImageSize = jcprops.JPGWidth * jcprops.JPGHeight *
		jcprops.DIBChannels;
	
		lpTemp = new BYTE [dwWholeImageSize];
		if(NULL == lpTemp)
		{
			bres = FALSE;
			__leave;
		}
	
		jcprops.DIBWidth = jcprops.JPGWidth;
		jcprops.DIBHeight = jcprops.JPGHeight;
		jcprops.DIBPadBytes = 0;
		jcprops.DIBBytes = lpTemp;
	
		jerr = ijlRead(&jcprops, IJL_JBUFF_READWHOLEIMAGE);
		if(IJL_OK != jerr)
		{
			bres = FALSE;
			__leave;
		}
	} 
	__finally
	{
		if(FALSE == bres)
		{
			if(NULL != lpTemp)
			{
				delete [] lpTemp;
				lpTemp = NULL;
			}
		}
		ijlFree(&jcprops);
		*lpdwWidth = jcprops.DIBWidth;
		*lpdwHeight = jcprops.DIBHeight;
		*lpdwNumberOfChannels = jcprops.DIBChannels;
		*lppRgbBuffer = lpTemp;
		} 
	return bres;
} 



int LoadGLTextures()								
{
	
	BYTE *buffer,*data;
	unsigned long width,height,nchannels;
	HRSRC hResInfo;
	HGLOBAL hglobal;
	LPVOID lpvoid;
	HMODULE hmodule;
	unsigned char *ucp;
	DWORD sizer;
	unsigned int a;

	
	hmodule=GetModuleHandle(NULL);/*"ammosaver.scr"*///);
	if (hmodule==NULL) MessageBox(NULL,"Chyba","zlyhal",MB_OK);
	hResInfo=FindResource(hmodule,MAKEINTRESOURCE(IDR_JPG1),"jpg");
	if (hResInfo==NULL) MessageBox(NULL,"Chyba","zlyhal hResInfo",MB_OK);
	hglobal=LoadResource(hmodule,hResInfo);
	if (hglobal==NULL) MessageBox(NULL,"Chyba","zlyhal hglobal",MB_OK);
	lpvoid=LockResource(hglobal);
	ucp=(unsigned char*) lpvoid;
	sizer=SizeofResource(hmodule,hResInfo);
	DecodeFromJPEGBuffer(ucp,sizer,&buffer,&width,&height,&nchannels);

	data = new BYTE[width*height*4];
	for (a=0;a<width*height;a++)
	{
		data[a*4]=buffer[a*3];
		data[a*4+1]=buffer[a*3+1];
		data[a*4+2]=buffer[a*3+2];
		data[a*4+3]=(BYTE)((255-buffer[a*3]*0.8f)/1.3f);

	}

	glGenTextures(1, &texture[0]);					
	// Create Linear Filtered Texture
	glBindTexture(GL_TEXTURE_2D, texture[0]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);

	free(buffer);
	
	//**** windows pozadie *************					
	glGenTextures(1, &texture[1]);					
	// Create Linear Filtered Texture
	glBindTexture(GL_TEXTURE_2D, texture[1]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, texture_s, texture_s, 0, GL_RGB, GL_UNSIGNED_BYTE, wscreen);
	
	//******* ammo
	hmodule=GetModuleHandle(NULL);
	if (hmodule==NULL) MessageBox(NULL,"Chyba","zlyhal",MB_OK);
	hResInfo=FindResource(hmodule,MAKEINTRESOURCE(IDR_JPG2),"jpg");
	if (hResInfo==NULL) MessageBox(NULL,"Chyba","zlyhal hResInfo",MB_OK);
	hglobal=LoadResource(hmodule,hResInfo);
	if (hglobal==NULL) MessageBox(NULL,"Chyba","zlyhal hglobal",MB_OK);
	lpvoid=LockResource(hglobal);
	ucp=(unsigned char*) lpvoid;
	sizer=SizeofResource(hmodule,hResInfo);
	DecodeFromJPEGBuffer(ucp,sizer,&buffer,&width,&height,&nchannels);

	data = new BYTE[width*height*4];
	for (a=0;a<width*height;a++)
	{
		data[a*4]=buffer[a*3];
		data[a*4+1]=buffer[a*3+1];
		data[a*4+2]=buffer[a*3+2];
		data[a*4+3]=(BYTE)( (buffer[a*3]+buffer[a*3+1]+buffer[a*3+1])/3 );

	}

	glGenTextures(1, &texture[2]);					
	glBindTexture(GL_TEXTURE_2D, texture[2]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
	free(buffer);

	return 0;								
}

