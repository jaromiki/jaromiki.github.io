#include "saver.h"
#include <scrnsave.h>

#define TIMER 1
int texture_s=512;

long width,height;
float a=0.3f,b=0.6f,c=0.3f,d=0;
int i,j=0;
BOOL erode;
HINSTANCE	hInstance;
BYTE *wscreen;

static void InitGL(HWND hWnd, HDC & hDC, HGLRC & hRC)
{
  
  PIXELFORMATDESCRIPTOR pfd;
  ZeroMemory( &pfd, sizeof pfd );
  pfd.nSize = sizeof pfd;
  pfd.nVersion = 1;
  pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
  pfd.iPixelType = PFD_TYPE_RGBA;
  pfd.cColorBits = 24;
	
  hDC = GetDC( hWnd );
	
  int i = ChoosePixelFormat( hDC, &pfd );  
  SetPixelFormat( hDC, i, &pfd );

  hRC = wglCreateContext( hDC );
  wglMakeCurrent( hDC, hRC );
	

}

static void CloseGL(HWND hWnd, HDC hDC, HGLRC hRC)
{

  wglMakeCurrent( NULL, NULL );
  wglDeleteContext( hRC );

  ReleaseDC( hWnd, hDC );

}


PBITMAPINFO CreateBitmapInfoStruct(HBITMAP hBmp)
{ 
    BITMAP bmp; 
    PBITMAPINFO pbmi; 
    WORD    cClrBits; 

    GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bmp);
        
    cClrBits = (WORD)(bmp.bmPlanes * bmp.bmBitsPixel); 
    if (cClrBits == 1) 
        cClrBits = 1; 
    else if (cClrBits <= 4) 
        cClrBits = 4; 
    else if (cClrBits <= 8) 
        cClrBits = 8; 
    else if (cClrBits <= 16) 
        cClrBits = 16; 
    else if (cClrBits <= 24) 
        cClrBits = 24; 
    else cClrBits = 32; 

     if (cClrBits != 24) 
         pbmi = (PBITMAPINFO) LocalAlloc(LPTR, 
                    sizeof(BITMAPINFOHEADER) + 
                    sizeof(RGBQUAD) * (1<< cClrBits)); 

     else 
         pbmi = (PBITMAPINFO) LocalAlloc(LPTR, 
                    sizeof(BITMAPINFOHEADER)); 

    pbmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER); 
    pbmi->bmiHeader.biWidth = bmp.bmWidth; 
    pbmi->bmiHeader.biHeight = bmp.bmHeight; 
    pbmi->bmiHeader.biPlanes = bmp.bmPlanes; 
    pbmi->bmiHeader.biBitCount = bmp.bmBitsPixel; 
    if (cClrBits < 24) 
        pbmi->bmiHeader.biClrUsed = (1<<cClrBits); 

    pbmi->bmiHeader.biCompression = BI_RGB; 
    pbmi->bmiHeader.biSizeImage = (pbmi->bmiHeader.biWidth + 7) /8*pbmi->bmiHeader.biHeight; 
	pbmi->bmiHeader.biClrImportant = 0; 
    
	return pbmi; 
} 
 


BYTE *save_screen()
{
	HDC hdc,hdcobrazok;
	HBITMAP hpozadie;
	BYTE *data,*pom;
	PBITMAPINFO pbmi;
	int pf;
	int err,a,r,g,b;

	hdc=CreateDC("DISPLAY", (LPCSTR) NULL, 
	              (LPCSTR) NULL, (CONST DEVMODE *) NULL); 

	hdcobrazok=CreateCompatibleDC(hdc);
	hpozadie=CreateCompatibleBitmap(hdc,texture_s,texture_s);
	SelectObject(hdcobrazok, hpozadie);
	err = StretchBlt(hdcobrazok,0,0,texture_s,texture_s,hdc,0,0,width,height,SRCCOPY);
	if (err==0) MessageBox(NULL,"ej","boha jeho",MB_OK);
	pbmi=CreateBitmapInfoStruct(hpozadie);
	pf=pbmi->bmiHeader.biBitCount/8;
	
	data = new BYTE[texture_s*texture_s*3];
	pom = new BYTE[texture_s*texture_s*pf];


	GetBitmapBits(hpozadie,texture_s*texture_s*pf,pom);
	switch (pf)
	{

		case 1:
			for (a=0; a<texture_s*texture_s; a++)
			{
				r=pom[a];
				g=r & 48;
				g=g*4;
				b=r & 12;
				b=b*16;
				r=r & 192;
				data[a*3]=r;
				data[a*3+1]=g;
				data[a*3+2]=b;
			}
			free(pom);
			break;

		case 2:
			for (a=0; a<texture_s*texture_s; a++)
			{
				r=pom[a*2+1]*256+pom[a*2];
				g=r & 1984;
				g=g/8;
				b=r & 31;
				b=b*8;
				r=r & 63488;
				r=r/256;		
	
				data[a*3]=r;
				data[a*3+1]=g;
				data[a*3+2]=b;
				
			}
			free(pom);
			break;

		case 3:
			for (a=0; a<texture_s*texture_s; a++)
			{
				data=pom;
			}
			break;
		case 4:
			for (a=0; a<texture_s*texture_s; a++)
			{
				data[a*3]=pom[a*4+2];
				data[a*3+1]=pom[a*4+1];
				data[a*3+2]=pom[a*4];
			}
			free(pom);
			break;
	}
	
	return data;
}


LRESULT WINAPI ScreenSaverProc(HWND hWnd, UINT message, 
                               WPARAM wParam, LPARAM lParam)
{
  static HDC hDC;
  static HGLRC hRC;
  static RECT rect;


  switch ( message ) 
  {

	case WM_CREATE: 
	    GetClientRect( hWnd, &rect );
	    width = rect.right;
	    height = rect.bottom;
		wscreen=save_screen();
	    InitGL( hWnd, hDC, hRC );
	    startup();
	    SetTimer( hWnd, TIMER, 1, NULL );
	    return 0;
 
	case WM_DESTROY:
	    
	    shutdown();
	    CloseGL( hWnd, hDC, hRC );
	    return 0;

	case WM_TIMER:
		{
			BOOLEAN gotMsg=0;
			MSG	msg;

			KillTimer( hWnd, TIMER );
			while (!gotMsg)
			{
				render();
				SwapBuffers(hDC);
				gotMsg=PeekMessage(&msg, NULL, 0, 0, 0);
			}
		}
  		return 0;

	case WM_ERASEBKGND:
	    if ( erode ) return 0;
	    break;
  }
  
  return DefScreenSaverProc( hWnd, message, wParam, lParam );
}


BOOL WINAPI ScreenSaverConfigureDialog(HWND hDlg, UINT message, 
                           WPARAM wParam, LPARAM lParam)
{
  return TRUE;
}


BOOL WINAPI RegisterDialogClasses(HANDLE hInst)
{
  return TRUE;
}
