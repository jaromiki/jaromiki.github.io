
#include <windows.h>
#include <GL/gl.h>
#include <GL/glaux.h>


extern long width,height;
extern BOOL erode;


extern void startup();
extern void shutdown();
extern void render();