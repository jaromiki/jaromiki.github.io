#include "saver.h"
#include "textures.h"
#include <math.h>

float M_PI=3.141592654f;
float M_SQRTPI=1.772453851f;

int r1,r2;
extern float a,b,c,d;
float fac=0.75;

static void configgl()
{
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	glFrustum( -0.1f, 0.1f, -0.1f, 0.1f, 0.2f, 5.0f );
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
  
	glShadeModel( GL_SMOOTH );
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);							
	glDepthFunc(GL_LEQUAL);								
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);	
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	LoadGLTextures();
}

void startup()
{
	srand( GetTickCount() );
	configgl();
}

void shutdown()
{
}

void render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	
	
	glLoadIdentity();
	
	a+=0.0007f;
	b+=0.001f;
	c+=0.0016f;
	d+=0.005f;
	glColor4f(1,1,1,1);
	glTranslatef(0.0f,0.0f,-1.5f);
	
	glBindTexture(GL_TEXTURE_2D, texture[1]);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(-1.00f*fac,-0.75f,0);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(1.00f*fac,-0.75f,0);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(1.00f*fac,0.75f,0);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(-1.00f*fac,0.75f,0);
	glEnd();

	glTranslatef(0.0f,0.0f,0.01f);
	glBindTexture(GL_TEXTURE_2D, texture[0]);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f+a, 1.0f+a);	glVertex3f(-1.00f*fac,-0.75f,0);
		glTexCoord2f(1.0f+a, 1.0f+a);	glVertex3f(1.00f*fac,-0.75f,0);
		glTexCoord2f(1.0f+a, 0.0f+a);	glVertex3f(1.00f*fac,0.75f,0);
		glTexCoord2f(0.0f+a, 0.0f+a);	glVertex3f(-1.00f*fac,0.75f,0);
	glEnd();
	
	glTranslatef(0.0f,0.0f,0.01f);
	glBindTexture(GL_TEXTURE_2D, texture[0]);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f+b, 1.0f+c);	glVertex3f(-1.00f*fac,-0.75f,0);
		glTexCoord2f(1.0f+b, 1.0f+c);	glVertex3f(1.00f*fac,-0.75f,0);
		glTexCoord2f(1.0f+b, 0.0f+c);	glVertex3f(1.00f*fac,0.75f,0);
		glTexCoord2f(0.0f+b, 0.0f+c);	glVertex3f(-1.00f*fac,0.75f,0);
	glEnd();
	
	if (d<1) glColor4f(1,1,1,d);
	if ((d>1) && (d<2)) glColor4f(1,1,1,1);
	if ((d>2) && (d<3)) glColor4f(1,1,1,3-d);
	if (d>3) glColor4f(1,1,1,0);
	
	glTranslatef((float)r1/100,(float)r2/100,0.01f);

	glBindTexture(GL_TEXTURE_2D, texture[2]);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(-0.40f*fac,-0.20f,0);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(0.40f*fac,-0.20f,0);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(0.40f*fac,0.20f,0);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(-0.40f*fac,0.20f,0);
	glEnd();


	if (a==1) a=0;
	if (b==1) b=0;
	if (c==1) c=0;
	if (d>=10) 
	{
		d=0;
		r1=rand()%80-40;
		r2=rand()%80-40;
	}

	glFlush();
}
