

#ifndef GUNMODEL_H
#define GUNMODEL_H

#include "MilkshapeModel.h"

class Cgunmodel : public MilkshapeModel
{
	public:
		void set_final(Matrix *final);

};

#endif