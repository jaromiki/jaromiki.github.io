#ifndef JPG_H
#define JPG_H

//#pragma comment(lib, "ijl15l.lib")					//Link to OpenGL32.lib so we can use OpenGL stuff

#include <windows.h>									// Standard windows header
#include "texture.h"
#include "ijl.h"


bool loadjpg(Texture *, char *);	


#endif






