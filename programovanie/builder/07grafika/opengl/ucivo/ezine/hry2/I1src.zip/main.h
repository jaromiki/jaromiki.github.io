#ifndef MAIN_H
#define MAIN_H

#define SCREEN_WIDTH 800								// We want our screen width 800 pixels
#define SCREEN_HEIGHT 600								// We want our screen height 600 pixels
#define SCREEN_DEPTH 32									// We want 16 bits per pixel

extern HDC			hDC;			// Private GDI Device Context
extern HGLRC		hRC;			// Permanent Rendering Context
extern HWND			hWnd;			// Holds Our Window Handle
extern HINSTANCE	hInstance;		// Holds The Instance Of The Application

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

GLvoid ReSizeGLScene(GLsizei width, GLsizei height);		// Resize And Initialize The GL Window

int InitGL(GLvoid);										// All Setup For OpenGL Goes Here

int DrawGLScene(GLvoid);									// Here's Where We Do All The Drawing

GLvoid KillGLWindow(GLvoid);								// Properly Kill The Window

BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag);

LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam);		// Additional Message Information


#endif