
#include <string.h>
#include "Texture.h"
#include <gl/glu.h>

int t_BMP=1,
	t_TGA=2,
	t_JPG=3;

bool LoadTGA(Texture *, char *);					
bool loadbmp(Texture *, char *);						
bool loadjpg(Texture *, char *);					

int get_type(const char *filename)
{
	int len;
	char typ[4];

	len = strlen(filename);
	
	typ[3] = '\0';
	typ[2] = filename[len-1];
	typ[1] = filename[len-2];
	typ[0] = filename[len-3];

	if (     (strcmp(typ,"BMP") == 0) 
		  || (strcmp(typ,"bmp") == 0) 
		  || (strcmp(typ,"Bmp") == 0)  ) return 1;
	if (     (strcmp(typ,"TGA") == 0) 
		  || (strcmp(typ,"tga") == 0) 
		  || (strcmp(typ,"Tga") == 0)  ) return 2;
	if (     (strcmp(typ,"JPG") == 0) 
		  || (strcmp(typ,"jpg") == 0) 
		  || (strcmp(typ,"Jpg") == 0) 
		  || (strcmp(typ,"JPEG") == 0) 
		  || (strcmp(typ,"jpeg") == 0) 
		  || (strcmp(typ,"Jpeg") == 0) ) return 3;
	return -1;

}

int load_image(char *filename, int type, Texture *texture)
{
	int result=0;
	
	switch(type)
	{
		case 1: result=loadbmp( texture, filename ); break;
		case 2: result=LoadTGA( texture, filename ); break;
		case 3: result=loadjpg( texture, filename ); break;
	}

			


	return result;
}

GLuint LoadGLTexture(char *filename )			// Load Bitmaps And Convert To Textures
{
	Texture texture;
	int type;
	
	type = get_type(filename);

	if (!load_image(filename, type, &texture))
	{
		MessageBox( NULL,"FAILED !!!","Loading texture...",MB_OK );
		return 0;
	}
	
/*	if ( !LoadTGA( &texture, const_cast<char*>( filename ))) {
		return 0;
	}*/
	
	glGenTextures(1, &texture.texID);						// Create The Texture

	// Typical Texture Generation Using Data From The Bitmap
	glBindTexture(GL_TEXTURE_2D, texture.texID);

//	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, texture.width, texture.height, GL_RGB, GL_UNSIGNED_BYTE, texture.imageData);

	glTexImage2D(GL_TEXTURE_2D, 0, 3, texture.width, texture.height, 0, GL_RGB, GL_UNSIGNED_BYTE, texture.imageData);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

	if (texture.imageData)						// If Texture Image Exists ( CHANGE )
	{
		free(texture.imageData);					// Free The Texture Image Memory ( CHANGE )
	}

	return texture.texID;										// Return The Status
}

void destroy_texture( GLsizei n, GLuint *textures )
{
	glDeleteTextures( n, textures );
}
 
