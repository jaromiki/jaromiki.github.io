#include "gunmodel.h"



void Cgunmodel::set_final(Matrix *final)
{
	Matrix relativefinal;

	//relativefinal.set(m_pJoints[0].m_relative.getMatrix());
	//m_pJoints[0].m_final.set( relativefinal.getMatrix() );
	//m_pJoints[0].m_final.postMultiply( *final );
	m_pJoints[0].m_final.set( final->getMatrix() );
}

