#ifndef FONT_H
#define FONT_H

#include <windows.h>


class Cwinfont
{
	public:
		Cwinfont();
		Cwinfont(int mc, int fh);
		~Cwinfont();

		UINT CreateOpenGLFont(LPSTR strFontName, int height);	// Build Our Bitmap Font
		void Build(char *name, int height);
		void PositionText( int x, int y );
		void glDrawText(int x, int y, const char *strString, ...);
		void DestroyFont();
	private:
		UINT g_FontListID;
		HFONT hOldFont;
		int max_chars;
		int font_height;
};


class Cimgfont
{
	public:
		Cimgfont(char *name);
		~Cimgfont();

		void BuildFont();
		void KillFont();
		void glPrint(GLint x, GLint y, char *string, int set);
	private:
		GLuint	base;				// Base Display List For The Font
		GLuint	texture;
		
};

#endif