#ifndef BMP_H
#define BMP_H

//#pragma comment(lib, "glaux.lib")					//Link to OpenGL32.lib so we can use OpenGL stuff

#include <windows.h>									// Standard windows header
#include <gl\glaux.h>										// Header for OpenGL32 library
#include "texture.h"


bool loadbmp(Texture *, char *);	


#endif






