
#include "bmp.h"

bool loadbmp(Texture *texture, char *Filename)		// Loads A Bitmap Image
{
	AUX_RGBImageRec *image;
	FILE *File=NULL;									// File Handle

	if (!Filename)										// Make Sure A Filename Was Given
	{
		return 0;										// If Not Return NULL
	}

	File=fopen(Filename,"r");							// Check To See If The File Exists

	if (File)											// Does The File Exist?
	{
		fclose(File);									// Close The Handle
		image=auxDIBImageLoad(Filename);				// Load The Bitmap And Return A Pointer
		texture->bpp=24;
		texture->imageData=image->data;
		texture->width=image->sizeX;
		texture->height=image->sizeY;
		texture->type=GL_RGB;			
		return 1;
	}

	return 0;										// If Load Failed Return NULL
}

