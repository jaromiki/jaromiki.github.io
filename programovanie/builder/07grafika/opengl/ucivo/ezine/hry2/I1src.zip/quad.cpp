#include "quad.h"

Cquad::Cquad()
{
	int i;
	for (i=0;i<4;i++)
	{
		u[i]=0;
		v[i]=0;
	}
	texture.texID=0;
}

Cquad::~Cquad()
{
	destroy_texture(1,&texture.texID);
}

void Cquad::load_texture(char *name)
{
	if (texture.texID!=0) destroy_texture(1,&texture.texID);
	texture.texID=LoadGLTexture(name);
}

void Cquad::bind()
{
	glBindTexture(GL_TEXTURE_2D, texture.texID);
}

void Cquad::draw(float x[4], float y[4], float z[4])
{
	bind();
	glBegin(GL_QUADS);
		glTexCoord2f(u[0], v[0]); 
		glVertex3f(x[0], y[0],  z[0]);

		glTexCoord2f(u[1], v[1]); 
		glVertex3f(x[1], y[1],  z[1]);

		glTexCoord2f(u[2], v[2]); 
		glVertex3f(x[2], y[2],  z[2]);

		glTexCoord2f(u[3], v[3]); 
		glVertex3f(x[3], y[3],  z[3]);
	glEnd();

}

void Cquad::setr(float rrx, float rry)
{
	rx=rrx;
	ry=rry;
}

void Cquad::setuv(float uu[4], float vv[4])
{
	int i;
	for (i=0; i<4; i++)
	{
		u[i]=uu[i];
		v[i]=vv[i];
	}

}

void Cquad::cycle()
{
	int i;
	for (i=0;i<4;i++)
	{
		u[i]+=rx;
		v[i]+=ry;
	}
}

