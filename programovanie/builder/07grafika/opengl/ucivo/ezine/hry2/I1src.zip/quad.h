#ifndef QUAD_H
#define QUAD_H

//#pragma comment(lib, "opengl.lib")					//Link to OpenGL32.lib so we can use OpenGL stuff

#include <windows.h>									// Standard windows header
#include <gl\gl.h>										// Header for OpenGL32 library
#include "texture.h"


class Cquad
{
	private:
		float u[4];
		float v[4];
		float rx, ry;
		Texture texture;

	public:
		Cquad();
		~Cquad();
		void load_texture(char *name);
		void bind();
		void setr(float rrx, float rry);
		void setuv(float uu[4], float vv[4]);
		void cycle();
		void draw(float x[4], float y[4], float z[4]);

};


#endif

