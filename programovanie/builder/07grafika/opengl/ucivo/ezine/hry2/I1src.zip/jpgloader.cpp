#include "jpg.h"

int DecodeJPGFileToGeneralBuffer(LPCSTR lpszPathName, unsigned int *width, unsigned int *height, 
								 unsigned int *nchannels, BYTE **buffer)
{
	BOOL bres;
	IJLERR jerr;
	DWORD x = 0; // pixels in scan line
	DWORD y = 0; // number of scan lines
	DWORD c = 0; // number of channels
	DWORD wholeimagesize;
	BYTE* pixel_buf = NULL;
	JPEG_CORE_PROPERTIES jcprops; // Allocate the IJL JPEG_CORE_PROPERTIES structure.
	
	bres = TRUE;
	jerr = ijlInit(&jcprops); // Initialize the IntelR JPEG Library.
	if(IJL_OK != jerr)
		{
			bres = FALSE;
		}
	
	jcprops.JPGFile = const_cast<LPSTR>(lpszPathName); // Get information on the JPEG image(i.e., width, height, and channels).
	jerr = ijlRead(&jcprops, IJL_JFILE_READPARAMS);
	if(IJL_OK != jerr)
	{
		bres = FALSE;
		
	}
	
	x = jcprops.JPGWidth; // Set up local data.
	y = jcprops.JPGHeight;
	c = 3; // Decode into a 3 channel pixel buffer.
	wholeimagesize = (x*y*c); // Compute size of desired pixel buffer.
	pixel_buf = new BYTE [wholeimagesize]; // Allocate memory to hold the decompressed image data.
	if(NULL == pixel_buf)
	{
		bres = FALSE;
	}
	
	jcprops.DIBWidth = x; // Set up the info on the desired DIB properties.
	jcprops.DIBHeight = -y; // Implies a bottom-up DIB.
	jcprops.DIBChannels = c;
	jcprops.DIBColor = IJL_RGB;
	
	jcprops.DIBPadBytes = 0;
	jcprops.DIBBytes = pixel_buf;
	switch(jcprops.JPGChannels)
	{
	case 1:
	{
		jcprops.JPGColor = IJL_G;
		break;
	}
	case 3:
	{
		jcprops.JPGColor = IJL_YCBCR;
		break;
	}
	default:
	{
		jcprops.DIBColor = (IJL_COLOR)IJL_OTHER;
		jcprops.JPGColor = (IJL_COLOR)IJL_OTHER;
		break;
	}
	}
	
	jerr = ijlRead(&jcprops, IJL_JFILE_READWHOLEIMAGE); // Now get the actual JPEG image data into the pixel buffer.
	if(IJL_OK != jerr)
	{
		bres = FALSE;
	
	} 

	if(FALSE == bres)
	{
		if(NULL != pixel_buf)
		{
			delete [] pixel_buf;
			pixel_buf = NULL;
		}
	}
	
	ijlFree(&jcprops); // Clean up the IntelR JPEG Library.
	*width = x;
	*height = y;
	*nchannels = c;
	*buffer = pixel_buf;
 	return bres;
}


bool loadjpg(Texture *texture, char *filename)
{
		
	BYTE *buffer;
	
	if ( !DecodeJPGFileToGeneralBuffer( filename, &texture->width, &texture->height, 
			 						    &texture->bpp, &buffer ) ) return 0;
	texture->bpp *= 8;
	texture->imageData=buffer;
	return 1;
}

