#include <windows.h>			// hlav. Subor pre Windows
#include <gl\gl.h>				// hlav. Subor pre OpenGL32 kniznicu
#include <gl\glu.h>				// hlav. Subor pre GLu32 kniznicu
#include <gl\glaux.h>			// hlav. Subor pre GLaux kniznicu

      
HGLRC	hRC=NULL;			// Rendering Context
HDC		hDC=NULL;			// Private GDI Device Context
HWND	hWnd=NULL;			// Window Handle
HINSTANCE	hInstance;		// Instance Of The Application

  
bool	keys[256];			// pole pou�it� pre kl�vesy
bool	active=TRUE;		// active flag, nastav�me na TRUE
bool	fullscreen=TRUE;	// fullscreen, d�me na TRUE
   

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);				// deklar�cia WndProc
  

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)	
// zm�na ve�kosti a inicializ�cia GL Window
{
	if (height==0)			// nulou deli� nechceme
	{
		height=1;			// nasatv�me na 1
	}

	glViewport(0, 0, width, height);		// nastav�me viewport (vidite�n� �as�)
	glMatrixMode(GL_PROJECTION);			// vyber Projection Matrix
	glLoadIdentity();						// resetni Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);

	glMatrixMode(GL_MODELVIEW);		// vyber Modelview Matrix
	glLoadIdentity();				// resetni Modelview Matrix
}
 

int InitGL(GLvoid)				// cel� setup OpenGL ide sem
{

	glShadeModel(GL_SMOOTH);	// zapneme Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);		// �ierne pozadie

 	glClearDepth(1.0f);			// depth buffer setup
	glEnable(GL_DEPTH_TEST);	// zapneme depth testovanie
	glDepthFunc(GL_LEQUAL);		// typ depth funkcie

     	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);			


	return TRUE;				// v�etko i�lo OK
}
    


int DrawGLScene(GLvoid)		// t�to funckia kresl�
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);		
	// vy�ist�me obrazovku a Depth Buffer
	glLoadIdentity();		

	glTranslatef(-1.5f,0.0f,-6.0f);		// do�ava 1.5, dozadu 6.0

	glBegin(GL_TRIANGLES);				// kresl�me trojuholn�ky
		glVertex3f( 0.0f, 1.0f, 0.0f);	// vrch
		glVertex3f(-1.0f,-1.0f, 0.0f);	// v�avo dole
		glVertex3f( 1.0f,-1.0f, 0.0f);	// vpravo dole
	glEnd();							// koniec trojuhln�kov

    glTranslatef(3.0f,0.0f,0.0f);					// doprava o 3

  	glBegin(GL_QUADS);					// kresl�me �tvorec
		glVertex3f(-1.0f, 1.0f, 0.0f);	// v�avo hore
		glVertex3f( 1.0f, 1.0f, 0.0f);	// vpravo hore
		glVertex3f( 1.0f,-1.0f, 0.0f);	// vpravo dole
		glVertex3f(-1.0f,-1.0f, 0.0f);	// v�avo dole
	glEnd();							// koniec �tvorcov
	return TRUE;						
}



GLvoid KillGLWindow(GLvoid)		// zni�i OpenGL okno
{

	if (fullscreen)				// fullscreen ?
	{

  		ChangeDisplaySettings(NULL,0);	// sp� na Desktop
		ShowCursor(TRUE);		// uk� kurzor
	}

      
	if (hRC)					// m�me Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))
		// m��eme uvo�ni� DC a RC Contexty?
		{

    

			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

	

		if (!wglDeleteContext(hRC))		// m��me uvo�ni� RC?
		{

    

			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;						// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))	// m��eme uvo�ni� DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;						// nastav DC na NULL
	}

	if (hWnd && !DestroyWindow(hWnd))	// m��eme zni�i� Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;						// nastav hWnd na NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))	// m��eme unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;							// Set hInstance To NULL
	}
}

     
BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{

	GLuint		PixelFormat;// v�sledky h�adania
	WNDCLASS	wc;			// �trukt�ra Windows Class
     
	DWORD		dwExStyle;	// �t�l okna (roz��ren�)
	DWORD		dwStyle;	// �t�l okna 

	RECT WindowRect;				// obd��nik
	WindowRect.left=(long)0;		// �av� hodnota na 0
	WindowRect.right=(long)width;	// prav� na Width
	WindowRect.top=(long)0;			// top na 0
	WindowRect.bottom=(long)height;	// Bottom na Height
    
	fullscreen=fullscreenflag;		// Set The Global Fullscreen Flag

	hInstance		= GetModuleHandle(NULL);
	wc.style		= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;		// prekresli pri pohybe a zmene ve�kosti
	wc.lpfnWndProc		= (WNDPROC) WndProc;				
	wc.cbClsExtra		= 0;						// �iadne extra data
	wc.cbWndExtra		= 0;						// �iadne extra data
	wc.hInstance		= hInstance;				// nastav�me Instance
	wc.hIcon		= LoadIcon(NULL, IDI_WINLOGO);
													// nahr�me iconu
	wc.hCursor		= LoadCursor(NULL, IDC_ARROW);			
													// nahr�me kurzor my�i
	wc.hbrBackground	= NULL;						// �iadne pozadie
	wc.lpszMenuName		= NULL;						// nem�me Menu
	wc.lpszClassName	= "OpenGL";					// nastav�me meno Class

	if (!RegisterClass(&wc))						// pok�s sa zaregistrova� Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;				}
    
	if (fullscreen)					
	{

     		DEVMODE dmScreenSettings;		// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));		
		// pam� mus� by� �ist�
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		
		// ve�kos� DmScreenSettings
		dmScreenSettings.dmPelsWidth	= width;			
		// ��rka
		dmScreenSettings.dmPelsHeight	= height;			
		// v��ka
		dmScreenSettings.dmBitsPerPel	= bits;				
		// bits per pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

      
	
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
	     
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen=FALSE;	
			}
			else
			{
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;				}
		}
	}
     
	if (fullscreen)					// sme Fullscreen 
	{

		dwExStyle=WS_EX_APPWINDOW;	// Window Extended Style
		dwStyle=WS_POPUP;			// Windows Style
		ShowCursor(FALSE);			// skry my�
	}
	else
	{

	   	dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;	// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;					// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		

	if (!(hWnd=CreateWindowEx(	dwExStyle,							// extended style 
								"OpenGL",							// meno Class
								title,								// titulok Window
								dwStyle |							// Window Style
								WS_CLIPSIBLINGS |					// Window Style
								WS_CLIPCHILDREN,					// Window Style
								0, 0,								// poz�cia Window
								WindowRect.right-WindowRect.left,	
								WindowRect.bottom-WindowRect.top,	
								NULL,								
								NULL,								// �iadne Menu
								hInstance,							// Instance
								NULL)))							
	
 

	{
		KillGLWindow();				// Reset Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;				// vr� FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd=	
	{
		sizeof(PIXELFORMATDESCRIPTOR),				
		1,								
		PFD_DRAW_TO_WINDOW |						
		// podpora okna
		PFD_SUPPORT_OPENGL |						
		// podpora Opengl
		PFD_DOUBLEBUFFER,						
		// podpora double buffer
		PFD_TYPE_RGBA,							
		// rgba format
		bits,								
		// Color Depth
		0, 0, 0, 0, 0,0,	// Color Bits Ignored
		0,					// No Alpha Buffer
		0,					// Shift Bit Ignored
		0,					// No Accumulation Buffer
		0, 0, 0, 0,			// Accumulation Bits Ignored
		16,					// 16Bit Z-Buffer (Depth Buffer)			0,					// No Stencil Buffer
		0,					// No Auxiliary Buffer
		PFD_MAIN_PLANE,		// Main Drawing Layer
		0,					// Reserved
		0, 0, 0				// Layer Masks Ignored
	};

	if (!(hDC=GetDC(hWnd)))		// z�skali sme Device Context?
	{
		KillGLWindow();			// Reset Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;			// vr� FALSE
	}

      	
    	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))				
		// na�iel windows Pixel Format?
	{
		KillGLWindow();							
		// Reset Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;		// vr� FALSE
	}

      	
      
	if(!SetPixelFormat(hDC,PixelFormat,&pfd))				
		// m��me ho nastavi� ?
	{
		KillGLWindow();				// Reset Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;				// vr� FALSE
	}

	if (!(hRC=wglCreateContext(hDC)))
		// m��me z�ska� Rendering Context?
	{
		KillGLWindow();			// Reset Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;			// vr� FALSE
	}

      

	if(!wglMakeCurrent(hDC,hRC))	// sk�s aktivova� Rendering Context
	{
		KillGLWindow();		// Reset Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;		// vr� FALSE
	}

	ShowWindow(hWnd,SW_SHOW);		// uk� okno Window
	SetForegroundWindow(hWnd);		
	SetFocus(hWnd);				//  Keyboard Focus na na�e okno
	ReSizeGLScene(width, height);		// nastav Perspekt�vu 
 
	if (!InitGL())					
{
		KillGLWindow();		// Reset Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;		// vr� FALSE
	}
  
	return TRUE;				
}

      
	
      

LRESULT CALLBACK WndProc(	HWND	hWnd,					
				// Handle na Window
				UINT	uMsg,					
				// spr�va pre n� Window
				WPARAM	wParam,					
				// parametre
				LPARAM	lParam)					
				// paramtre
{
     
	switch (uMsg)					{


		case WM_ACTIVATE:	// spr�va Activate
		{
			if (!HIWORD(wParam))	// Check Minimization State
			{
				active=TRUE;		// Program je Akt�vny
			}
			else
			{
				active=FALSE;	//program je neakt�vny
			}

			return 0;			
		}

		case WM_SYSCOMMAND:		
		{
			switch (wParam)		
			{
				case SC_SCREENSAVE:	// chce za�a� screensave?
				case SC_MONITORPOWER:  //vypnutie monitoru?
				return 0;		
			}
			break;				
		}

          		case WM_CLOSE:		// zatvarame?
		{
			PostQuitMessage(0);		// po�li Quit Message
			return 0;				// sko� sp�
		}

      		case WM_KEYDOWN:		// bol stla�en� kl�ves
		{
			keys[wParam] = TRUE;	// ak hej, zazna� to
			return 0;			
		}
      
     		case WM_KEYUP:			// bol pusten�?
		{
			keys[wParam] = FALSE;	// zazna� ako FALSE
			return 0;			 
		}

     		case WM_SIZE:			// pri zmene OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));		
			// LoWord=��rka, HiWord=v��ka
			return 0;		
		}
	}
 	// ostatn� spr�vy do DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}


int WINAPI WinMain(	HINSTANCE	hInstance,		// Instance
			HINSTANCE	hPrevInstance,		// Previous Instance
			LPSTR		lpCmdLine,		// paramtre
			int		nCmdShow)			
{
   	MSG	msg;						// �trukt�ra messsage	
BOOL	done=FALSE;					

      

	// chce ���vate� fullscreen ?
	if (MessageBox(NULL,"Would You Like To Run In Fullscreen Mode?", "Start FullScreen?",MB_YESNO|MB_ICONQUESTION)==IDNO)
	{
		fullscreen=FALSE;				// chce Window
	}

      	// vytvor OpenGL Window
	if (!CreateGLWindow("OpenGL Framework",640,480,16,fullscreen))
	{
		return 0;					
	}

      	while(!done)	// k�m je done==FALSE
	{

	if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))			
		// nejak� spr�va?
		{

		if (msg.message==WM_QUIT)	
		// treba kon�i� ?
			{
				done=TRUE;					
}
			else				
			{
TranslateMessage(&msg);					DispatchMessage(&msg);	
			}
		}
		else			// �iadne spr�vy
		{

		// nakresli OpenGL sc�nu a pozri �i nie je stla�en� Esc.
			if (active)				// akt�vne
			{
				if (keys[VK_ESCAPE])		// stla�en� ESC ?
				{
					done=TRUE;		
				}
				else			// nekon��me, Updatni obrazovku
				{
					DrawGLScene();	// kresli Sc�nu
					SwapBuffers(hDC);	// (Double Buffering)
				}
			}
			if (keys[VK_F1])			// F1 stla�en�?
			{
				keys[VK_F1]=FALSE;	
			KillGLWindow();									fullscreen=!fullscreen;	

				if (!CreateGLWindow("First Polygon Tutorial",640,480,16,fullscreen))
				{
					return 0;	
				}
			}
		}
	}

	// Shutdown
	KillGLWindow();				// Kill Window
	return (msg.wParam);		// Exit Program
}

