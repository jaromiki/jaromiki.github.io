#ifndef EXAMPLE_H
#define EXAMPLE_H

#include "aggressiveoptimize.h"
#include <windows.h>
#include <gl\gl.h>				
#include <gl\glu.h>				
#include <gl\glaux.h>			
#include "resource.h"

#define TEXTURELOADFROMFILE
#define TEXTURELOADFROMRESOURCE

#endif