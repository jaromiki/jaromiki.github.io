////////////////////////////////////////////////////////////////////////////////
//  File:   texture.h
//  Name:   CTexture Class (h)
//  Auhtor: Johny, johny@ammo.sk, www.ammo.sk
//  Date:   
//          Based on Nehe IPicture
//          Loads BMP, EMF, GIF, ICO, JPG, WMF
////////////////////////////////////////////////////////////////////////////////


#ifndef TEXTURE_H
#define TEXTURE_H

#include <math.h>
#include <olectl.h>
#include "example.h"

class CTexture
{
	private:
		static void safeRelease(IPicture *pPicture);

#ifdef TEXTURELOADFROMFILE	
	private:
		static int getType(const char *strFile);
		static GLuint loadBmpGifJpgFromFile(const char *strImage, const char *strMask, bool bMipMap, bool bRelativePath);
	public:
		static GLuint loadTexture(const char *strImage, const char *strMask=NULL, bool bMipMap=0, bool bRelativePath=1);
#endif

#ifdef TEXTURELOADFROMRESOURCE
	private:
		static GLuint loadBmpGifJpgFromResource(const char *strType, const int nImageID, const int nMaskID, bool bMipMap);
	public:
		static GLuint loadTexture(const char *strType, const int nImageID, const int nMaskID=0, bool bMipMap=0);
#endif
};


#endif