////////////////////////////////////////////////////////////////////////////////
//  File:   texture.cpp
//  Name:   CTexture Class (h)
//  Auhtor: Johny, johny@ammo.sk, www.ammo.sk
//  Date:  
//			Based on Nehe IPicture 
////////////////////////////////////////////////////////////////////////////////

#include "texture.h"

void CTexture::safeRelease(IPicture *pPicture)
{
	if (pPicture!=NULL)
		pPicture->Release();
}


#ifdef TEXTURELOADFROMFILE

int CTexture::getType(const char *strFile)
{
	int nLen;
	char typ[4];

	if (strFile==NULL) return 0;
	nLen = strlen(strFile);
	if (nLen<3) return 0;

	typ[3] = '\0';
	typ[2] = strFile[nLen-1];
	typ[1] = strFile[nLen-2];
	typ[0] = strFile[nLen-3];

	strlwr(typ);

	if ( strcmp(typ,"bmp") == 0 ) return 1;
	if ( strcmp(typ,"tga") == 0 ) return 2;
	if (    (strcmp(typ,"jpg" ) == 0) 
	     || (strcmp(typ,"jpeg") == 0) ) return 3;
	if ( strcmp(typ,"gif") == 0 ) return 4;
	if ( strcmp(typ,"png") == 0 ) return 5;
	return 0;
}

GLuint CTexture::loadTexture(const char *strImage, const char *strMask, bool bMipMap, bool bRelativePath)
{
	GLuint nResult=0;
	
	int nImageType=getType(strImage);
	int nMaskType=getType(strMask);
	
	switch(nImageType)
	{
		case 1:
		case 3:
		case 4:
				nResult=loadBmpGifJpgFromFile(strImage, strMask, bMipMap, bRelativePath); break;
		//case 2: nResult=LoadTga(strName); break;
		//case 5: nResult=LoadPng(strName); break;
	}

	return nResult;
}

GLuint CTexture::loadBmpGifJpgFromFile(const char *strImage, const char *strMask, bool bMipMap, bool bRelativePath)
{
	HDC			hDCImage=NULL;									// The DC To Hold Our Bitmap
	HDC			hDCMask=NULL;
	HBITMAP		hBmpImage=NULL;									// Holds The Bitmap Temporarily
	HBITMAP		hBmpMask=NULL;
	IPicture	*pPictureImage=NULL;							// IPicture Interface
	IPicture	*pPictureMask=NULL;
	OLECHAR		wstrPathImage[_MAX_PATH+_MAX_FNAME+1];			// Full Path To Picture (WCHAR)
	OLECHAR		wstrPathMask[_MAX_PATH+_MAX_FNAME+1];
	char		strPathImage[_MAX_PATH+_MAX_FNAME+1];
	char		strPathMask[_MAX_PATH+_MAX_FNAME+1];
	long		lWidth=0;										// Width In Logical Units
	long		lHeight=0;										// Height In Logical Units
	long		lWidthPixels=0;									// Width In Pixels
	long		lHeightPixels=0;								// Height In Pixels
	GLint		nMaxTexDim=0;									// Holds Maximum Texture Size
	GLuint		nTextureID=0;
	bool		bMask=true;
	HRESULT hImageResult=NULL;
	HRESULT hMaskResult=NULL;

	if (strImage==NULL) return 0;
	if (strMask==NULL) bMask=false;
	
	if (bRelativePath)
	{
		GetCurrentDirectory(_MAX_PATH, strPathImage);
		strcat(strPathImage, "\\");
		
		if (bMask)
		{
			strcpy(strPathMask, strPathImage);
			strcat(strPathMask, strMask);
		}
		strcat(strPathImage, strImage);
	}
	else
	{
		strcpy(strPathImage, strImage);
		if (bMask) strcpy(strPathMask, strMask);
	}
	
	MultiByteToWideChar(CP_ACP, 0, strPathImage, -1, wstrPathImage, _MAX_PATH+_MAX_FNAME);
	if (bMask) MultiByteToWideChar(CP_ACP, 0, strPathMask, -1, wstrPathMask, _MAX_PATH+_MAX_FNAME);
	
	hImageResult = OleLoadPicturePath(wstrPathImage, 0, 0, 0, IID_IPicture, (void**) &pPictureImage);
	if (bMask) hMaskResult = OleLoadPicturePath(wstrPathMask, 0, 0, 0, IID_IPicture, (void**) &pPictureMask);

	if ( FAILED(hImageResult) ) 
	{
		safeRelease(pPictureImage);
		safeRelease(pPictureMask);
		return 0;
	}

	if (FAILED(hMaskResult)) bMask=false;		
	
	// Create The Windows Compatible Device Context
	hDCImage = CreateCompatibleDC(GetDC(NULL));					
	if(!hDCImage)
	{
		safeRelease(pPictureImage);
		safeRelease(pPictureMask);
		return 0;
	}

	if (bMask)
	{
		// Create The Windows Compatible Device Context
		hDCMask = CreateCompatibleDC(GetDC(NULL));				
		if(!hDCMask)
		{
			safeRelease(pPictureMask);
			bMask=false;
		}		
	}

	// Get Maximum Texture Size Supported
	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &nMaxTexDim);			
	
	pPictureImage->get_Width(&lWidth);
	lWidthPixels=MulDiv(lWidth, GetDeviceCaps(hDCImage, LOGPIXELSX), 2540);
	pPictureImage->get_Height(&lHeight);
	lHeightPixels=MulDiv(lHeight, GetDeviceCaps(hDCImage, LOGPIXELSY), 2540);

	// Resize Image To Closest Power Of Two
	// Is Image Width Less Than Or Equal To Cards Limit
	// Otherwise  Set Width To "Max Power Of Two" That The Card Can Handle
	if (lWidthPixels <= nMaxTexDim)												
		lWidthPixels = 1 << (int) floor((log((double)lWidthPixels)/log(2.0f)) + 0.5f); 
	else 
		lWidthPixels = nMaxTexDim;
 
	// Is Image Height Greater Than Cards Limit
	// Otherwise  Set Height To "Max Power Of Two" That The Card Can Handle
	if (lHeightPixels <= nMaxTexDim)
		lHeightPixels = 1 << (int) floor((log((double)lHeightPixels)/log(2.0f)) + 0.5f);
	else
		lHeightPixels = nMaxTexDim;
	
	//	Create A Temporary Bitmap

	DWORD *pBitsImage = NULL;
	BITMAPINFO	biImage = {0};
	biImage.bmiHeader.biSize		= sizeof(BITMAPINFOHEADER);			// Set Structure Size
	biImage.bmiHeader.biBitCount	= 32;								// 32 Bit
	biImage.bmiHeader.biWidth		= lWidthPixels;						// Power Of Two Width
	biImage.bmiHeader.biHeight		= lHeightPixels;					// Make Image Top Up (Positive Y-Axis)
	biImage.bmiHeader.biCompression	= BI_RGB;							// RGB Encoding
	biImage.bmiHeader.biPlanes		= 1;								// 1 Bitplane
	
	DWORD *pBitsMask=NULL;
	BITMAPINFO	biMask = {0};
	biMask.bmiHeader.biSize		= sizeof(BITMAPINFOHEADER);				// Set Structure Size
	biMask.bmiHeader.biBitCount	= 32;									// 32 Bit
	biMask.bmiHeader.biWidth		= lWidthPixels;						// Power Of Two Width
	biMask.bmiHeader.biHeight		= lHeightPixels;					// Make Image Top Up (Positive Y-Axis)
	biMask.bmiHeader.biCompression	= BI_RGB;							// RGB Encoding
	biMask.bmiHeader.biPlanes		= 1;								// 1 Bitplane


	//	Creating A Bitmap This Way Allows Us To Specify Color Depth And Gives Us Imediate Access To The Bits
	hBmpImage = CreateDIBSection(hDCImage, &biImage, DIB_RGB_COLORS, (void**) &pBitsImage, 0, 0);
	if(!hBmpImage)
	{
		DeleteDC(hDCImage);
		safeRelease(pPictureImage);
		if (bMask) 
		{
			DeleteDC(hDCMask);
			safeRelease(pPictureMask);
		}
		return 0;
	}

	SelectObject(hDCImage, hBmpImage);

	pPictureImage->Render(hDCImage, 0, 0, lWidthPixels, lHeightPixels, 0, lHeight, lWidth, -lHeight, 0);

	///////////////////////////////////// MASK //////////////////////////////
	//	Creating A Bitmap This Way Allows Us To Specify Color Depth And Gives Us Imediate Access To The Bits
	if (bMask)
	{
		hBmpMask = CreateDIBSection(hDCMask, &biMask, DIB_RGB_COLORS, (void**) &pBitsMask, 0, 0);
		if(!hBmpMask)
		{
			DeleteDC(hDCMask);
			safeRelease(pPictureMask);
			bMask=false;
		}
		else
		{
			SelectObject(hDCMask, hBmpMask);
			pPictureMask->Render(hDCMask, 0, 0, lWidthPixels, lHeightPixels, 0, lHeight, lWidth, -lHeight, 0);
		}
	}


																			// Convert From BGR To RGB Format And Add An Alpha Value Of 255
	for(long i = 0; i < lWidthPixels * lHeightPixels; i++)					// Loop Through All Of The Pixels
	{
		BYTE *pPixelImage	= (BYTE*)(&pBitsImage[i]);						// Grab The Current Pixel
		BYTE *pPixelMask	= (BYTE*)(&pBitsMask[i]);
		BYTE  temp			= pPixelImage[0];								// Store 1st Color In Temp Variable (Blue)
		pPixelImage[0]		= pPixelImage[2];								// Move Red Value To Correct Position (1st)
		pPixelImage[2]		= temp;											// Move Temp Value To Correct Blue Position (3rd)

		if (bMask) pPixelImage[3]=(pPixelMask[0]+pPixelMask[1]+pPixelMask[2])/3;
		else
			if ((pPixelImage[0]==0) && (pPixelImage[1]==0) && (pPixelImage[2]==0))
				pPixelImage[3]=0;
			else
				pPixelImage[3]=255;
	}

	// Create The Texture
	glGenTextures(1, &nTextureID);

	glBindTexture(GL_TEXTURE_2D, nTextureID);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);			// (Modify This For The Type Of Filtering You Want)
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);			// (Modify This For The Type Of Filtering You Want)
	
	if (bMipMap)
		gluBuild2DMipmaps(GL_TEXTURE_2D, 4, lWidthPixels, lHeightPixels, GL_RGBA, GL_UNSIGNED_BYTE, pBitsImage); 
	else
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, lWidthPixels, lHeightPixels, 0, GL_RGBA, GL_UNSIGNED_BYTE, pBitsImage);

	DeleteObject(hBmpImage);
	DeleteDC(hDCImage);
	
	if (bMask)
	{
		DeleteObject(hBmpMask);
		DeleteDC(hDCMask);
	}

	safeRelease(pPictureImage);
	safeRelease(pPictureMask);

	return nTextureID;
}

#endif

#ifdef TEXTURELOADFROMRESOURCE

GLuint CTexture::loadTexture(const char *strType, const int nImageID, const int nMaskID, bool bMipMap)
{
	return loadBmpGifJpgFromResource(strType, nImageID, nMaskID, bMipMap);
}


GLuint CTexture::loadBmpGifJpgFromResource(const char *strType, const int nImageID, const int nMaskID, bool bMipMap)
{
	HDC			hDCImage=NULL;							// The DC To Hold Our Bitmap
	HDC			hDCMask=NULL;
	HBITMAP		hBmpImage=NULL;							// Holds The Bitmap Temporarily
	HBITMAP		hBmpMask=NULL;
	IPicture	*pPictureImage=NULL;					// IPicture Interface
	IPicture	*pPictureMask=NULL;
	long		lWidth=0;								// Width In Logical Units
	long		lHeight=0;								// Height In Logical Units
	long		lWidthPixels=0;							// Width In Pixels
	long		lHeightPixels=0;						// Height In Pixels
	GLint		nMaxTexDim=0;							// Holds Maximum Texture Size
	GLuint		nTextureID=0;
	bool		bMask=true;
	HRESULT hImageResult=NULL;
	HRESULT hMaskResult=NULL;
	HMODULE hModule=GetModuleHandle(NULL);
	HRSRC hResInfo=NULL;
	HGLOBAL hResource=NULL;
	int nResourceSize=0;
	void *pResource=NULL;
	HGLOBAL hGlobal=NULL;
	void *pGlobal=NULL;
	IStream *pStream=NULL;

	if (nImageID==0) return 0;
	if (nMaskID==0) bMask=false;
	
	
	hResInfo=FindResource(hModule, MAKEINTRESOURCE(nImageID), strType);
	hResource=LoadResource(hModule,hResInfo);
	nResourceSize=SizeofResource(hModule,hResInfo);
	pResource=LockResource(hResource);
	hGlobal=GlobalAlloc(GMEM_MOVEABLE,nResourceSize);
	pGlobal=GlobalLock(hGlobal);
	memcpy(pGlobal, pResource, nResourceSize);
	GlobalUnlock(hGlobal);
	UnlockResource(hResource);

	if (CreateStreamOnHGlobal(hGlobal,true,&pStream)!=S_OK)
	{
		GlobalFree(hGlobal);
		return 0;
	}
	hImageResult=OleLoadPicture(pStream, nResourceSize, false, IID_IPicture, (void**)&pPictureImage);
	pStream->Release();
	GlobalFree(hGlobal);
	
	if (bMask)
	{
		hResInfo=FindResource(hModule, MAKEINTRESOURCE(nMaskID), strType);
		hResource=LoadResource(hModule,hResInfo);
		nResourceSize=SizeofResource(hModule,hResInfo);
		pResource=LockResource(hResource);
		hGlobal=GlobalAlloc(GMEM_MOVEABLE,nResourceSize);
		pGlobal=GlobalLock(hGlobal);
		memcpy(pGlobal, pResource, nResourceSize);
		GlobalUnlock(hGlobal);
		UnlockResource(hResource);

		if (CreateStreamOnHGlobal(hGlobal,true,&pStream)!=S_OK)
		{
			GlobalFree(hGlobal);
			bMask=false;
		}
		hMaskResult=OleLoadPicture(pStream, nResourceSize, false, IID_IPicture, (void**)&pPictureMask);
		pStream->Release();
		GlobalFree(hGlobal);
	}

	
	if ( FAILED(hImageResult) ) 
	{
		safeRelease(pPictureImage);
		safeRelease(pPictureMask);
		return 0;
	}

	if (FAILED(hMaskResult)) bMask=false;		
	
	// Create The Windows Compatible Device Context
	hDCImage = CreateCompatibleDC(GetDC(NULL));
	if(!hDCImage)
	{
		safeRelease(pPictureImage);
		safeRelease(pPictureMask);
		return 0;
	}

	if (bMask)
	{
		// Create The Windows Compatible Device Context
		hDCMask = CreateCompatibleDC(GetDC(NULL));
		if(!hDCMask)
		{
			safeRelease(pPictureMask);
			bMask=false;
		}		
	}

	// Get Maximum Texture Size Supported
	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &nMaxTexDim);
	
	pPictureImage->get_Width(&lWidth);
	lWidthPixels=MulDiv(lWidth, GetDeviceCaps(hDCImage, LOGPIXELSX), 2540);
	pPictureImage->get_Height(&lHeight);
	lHeightPixels=MulDiv(lHeight, GetDeviceCaps(hDCImage, LOGPIXELSY), 2540);

	// Resize Image To Closest Power Of Two
	// Is Image Width Less Than Or Equal To Cards Limit
	// Otherwise  Set Width To "Max Power Of Two" That The Card Can Handle
	if (lWidthPixels <= nMaxTexDim)
		lWidthPixels = 1 << (int) floor((log((double)lWidthPixels)/log(2.0f)) + 0.5f); 
	else
		lWidthPixels = nMaxTexDim;
 
	if (lHeightPixels <= nMaxTexDim)
		lHeightPixels = 1 << (int) floor((log((double)lHeightPixels)/log(2.0f)) + 0.5f);
	else
		lHeightPixels = nMaxTexDim;
	
	//	Create A Temporary Bitmap

	DWORD *pBitsImage = NULL;
	BITMAPINFO	biImage = {0};
	biImage.bmiHeader.biSize		= sizeof(BITMAPINFOHEADER);			// Set Structure Size
	biImage.bmiHeader.biBitCount	= 32;								// 32 Bit
	biImage.bmiHeader.biWidth		= lWidthPixels;						// Power Of Two Width
	biImage.bmiHeader.biHeight		= lHeightPixels;					// Make Image Top Up (Positive Y-Axis)
	biImage.bmiHeader.biCompression	= BI_RGB;							// RGB Encoding
	biImage.bmiHeader.biPlanes		= 1;								// 1 Bitplane
	
	DWORD *pBitsMask=NULL;
	BITMAPINFO	biMask = {0};
	biMask.bmiHeader.biSize		= sizeof(BITMAPINFOHEADER);				// Set Structure Size
	biMask.bmiHeader.biBitCount	= 32;									// 32 Bit
	biMask.bmiHeader.biWidth		= lWidthPixels;						// Power Of Two Width
	biMask.bmiHeader.biHeight		= lHeightPixels;					// Make Image Top Up (Positive Y-Axis)
	biMask.bmiHeader.biCompression	= BI_RGB;							// RGB Encoding
	biMask.bmiHeader.biPlanes		= 1;								// 1 Bitplane


	//	Creating A Bitmap This Way Allows Us To Specify Color Depth And Gives Us Imediate Access To The Bits
	hBmpImage = CreateDIBSection(hDCImage, &biImage, DIB_RGB_COLORS, (void**) &pBitsImage, 0, 0);
	if(!hBmpImage)
	{
		DeleteDC(hDCImage);
		safeRelease(pPictureImage);
		if (bMask) 
		{
			DeleteDC(hDCMask);
			safeRelease(pPictureMask);
		}
		return 0;
	}

	SelectObject(hDCImage, hBmpImage);
	// Render The IPicture On To The Bitmap
	pPictureImage->Render(hDCImage, 0, 0, lWidthPixels, lHeightPixels, 0, lHeight, lWidth, -lHeight, 0);

	///////////////////////////////////// MASK //////////////////////////////
	//	Creating A Bitmap This Way Allows Us To Specify Color Depth And Gives Us Imediate Access To The Bits
	if (bMask)
	{
		hBmpMask = CreateDIBSection(hDCMask, &biMask, DIB_RGB_COLORS, (void**) &pBitsMask, 0, 0);
		if(!hBmpMask)
		{
			DeleteDC(hDCMask);
			safeRelease(pPictureMask);
			bMask=false;
		}
		else
		{
			SelectObject(hDCMask, hBmpMask);
			// Render The IPicture On To The Bitmap
			pPictureMask->Render(hDCMask, 0, 0, lWidthPixels, lHeightPixels, 0, lHeight, lWidth, -lHeight, 0);
		}
	}


																		// Convert From BGR To RGB Format And Add An Alpha Value Of 255
	for(long i = 0; i < lWidthPixels * lHeightPixels; i++)				// Loop Through All Of The Pixels
	{
		BYTE *pPixelImage	= (BYTE*)(&pBitsImage[i]);					// Grab The Current Pixel
		BYTE *pPixelMask	= (BYTE*)(&pBitsMask[i]);
		BYTE  temp			= pPixelImage[0];							// Store 1st Color In Temp Variable (Blue)
		pPixelImage[0]		= pPixelImage[2];							// Move Red Value To Correct Position (1st)
		pPixelImage[2]		= temp;										// Move Temp Value To Correct Blue Position (3rd)

		if (bMask) pPixelImage[3]=(pPixelMask[0]+pPixelMask[1]+pPixelMask[2])/3;
		else
			if ((pPixelImage[0]==0) && (pPixelImage[1]==0) && (pPixelImage[2]==0))
				pPixelImage[3]=0;
			else
				pPixelImage[3]=255;	
	}

	glGenTextures(1, &nTextureID);

	glBindTexture(GL_TEXTURE_2D, nTextureID);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);		// (Modify This For The Type Of Filtering You Want)
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);     // (Modify This For The Type Of Filtering You Want)

	if (bMipMap)
		gluBuild2DMipmaps(GL_TEXTURE_2D, 4, lWidthPixels, lHeightPixels, GL_RGBA, GL_UNSIGNED_BYTE, pBitsImage); 
	else
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, lWidthPixels, lHeightPixels, 0, GL_RGBA, GL_UNSIGNED_BYTE, pBitsImage);
	
	DeleteObject(hBmpImage);
	DeleteDC(hDCImage);
	
	if (bMask)
	{
		DeleteObject(hBmpMask);
		DeleteDC(hDCMask);
	}

	safeRelease(pPictureImage);
	safeRelease(pPictureMask);

	return nTextureID;
}

#endif

