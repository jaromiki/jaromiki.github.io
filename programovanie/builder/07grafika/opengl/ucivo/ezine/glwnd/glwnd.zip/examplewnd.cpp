////////////////////////////////////////////////////////////////////////////////
//  File:   examplewnd.cpp
//  Name:   CExampleWnd Class (cpp)
//  Auhtor: Johny, johny@ammo.sk, www.ammo.sk
//  Date:   20.05.2003
////////////////////////////////////////////////////////////////////////////////

#include "examplewnd.h"

CExampleWnd::CExampleWnd(HINSTANCE hInstance, char *strCmdLine)
	:CStdGLWnd(hInstance,strCmdLine)
{
}

bool CExampleWnd::Init()
{
	bool bResult=CStdGLWnd::Init();

	// Add/Modify
	m_fRot=0;

	return bResult;
}

bool CExampleWnd::DeInit()
{
	// Add/Modify
	
	return CStdGLWnd::DeInit();
}

bool CExampleWnd::InitGL() 
{
	//Add/Modify
	
	return CStdGLWnd::InitGL();
}

bool CExampleWnd::DrawGLScene() 
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	glTranslatef(-1.5f,0.0f,-6.0f);
	m_fRot+=0.5f;
	
	glRotatef(m_fRot,0,1,0);
	glBegin(GL_TRIANGLES);
	glColor3f(1.0f,0.0f,0.0f);
		glVertex3f( 0.0f, 1.0f, 0.0f);
		glColor3f(0.0f,1.0f,0.0f);
		glVertex3f(-1.0f,-1.0f, 0.0f);
		glColor3f(0.0f,0.0f,1.0f);
		glVertex3f( 1.0f,-1.0f, 0.0f);
	glEnd();

	glFlush();
	
	if (m_bKeys['A']) m_fRot+=5;

	return true;
}

