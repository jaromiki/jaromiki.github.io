////////////////////////////////////////////////////////////////////////////////
//  File:   stdglwnd.cpp
//  Name:   CStdGLWnd Class (cpp)
//  Auhtor: Johny, johny@ammo.sk, www.ammo.sk
//  Date:   20.05.2003
////////////////////////////////////////////////////////////////////////////////

#include "stdglwnd.h"

CStdGLWnd::CStdGLWnd(HINSTANCE hInstance, char *strCmdLine)
	:COpenGLWnd(hInstance,strCmdLine)
{
}

bool CStdGLWnd::Init()
{
	return COpenGLWnd::Init();
}

bool CStdGLWnd::DeInit()
{
	return COpenGLWnd::DeInit();
}

bool CStdGLWnd::InitGL() 
{
	glShadeModel(GL_SMOOTH);
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	
	return true;
}

bool CStdGLWnd::DrawGLScene() 
{
	return true;
}

LRESULT CStdGLWnd::WndProc(HWND   hWnd,    // Handle For This Window
                           UINT   Msg,    // Message For This Window
                           WPARAM wParam, // Additional Message Information
                           LPARAM lParam) // Additional Message Information
{
	switch (Msg) 
	{
		case WM_SYSCOMMAND: 
		{
			switch (int(wParam)) 
			{
				case SC_SCREENSAVE:  
				case SC_MONITORPOWER:
				return 0;				// don't call DefWindowProc
			}
			break;
		}

		case WM_KILLFOCUS:
		{
			m_bActive=false;
			break;
		}

		case WM_SETFOCUS:
		{
			m_bActive=true;
			break;
		}
		
		case WM_ACTIVATE:
		{
			if (HIWORD(wParam) || (wParam==WA_INACTIVE) )
			{
				m_bActive=false;
			}
			else
			{
				m_bActive=true;
			}
			break;
		}

		case WM_CLOSE: 
		{
			PostQuitMessage(0);
			break;
		}

		case WM_SIZE: 
		{
			int width  = LOWORD(lParam);
			int height = HIWORD(lParam);

			ResizeGLScene(width, height);
			break;
		}
		
		case WM_KEYDOWN:
		{
			m_bKeys[wParam] = true;
			if (m_bKeys[VK_ESCAPE]) PostQuitMessage(0);
			
			
			if (m_bKeys[VK_F1])
			{
				m_bKeys[VK_F1]=false;
				KillGLWindow();
				m_bFullScreen=!m_bFullScreen;
				if (!CreateGLWindow(m_strTitle, m_nWidth, m_nHeight, m_nBits, m_bFullScreen))
				{
					MessageBox(m_hWnd, "Can't create Wnd", "Error", MB_ICONERROR);	
					return 0;						// Quit If Window Was Not Created
				}
			}

			break;
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
			m_bKeys[wParam]=false;
			break;
		}
	} 
	return 1; // we need to call DefWindowProc
}
