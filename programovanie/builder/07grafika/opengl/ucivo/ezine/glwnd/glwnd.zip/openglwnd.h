////////////////////////////////////////////////////////////////////////////////
//  File:   openglwnd.h 
//  Name:   COpenGLWnd Class (h)
//  Auhtor: Johny, johny@ammo.sk, www.ammo.sk
//  Date:   20.05.2003
////////////////////////////////////////////////////////////////////////////////

#ifndef OPENGLWND_H
#define OPENGLWND_H

#define WIN32_LEAN_AND_MEAN

#include <windows.h>					// Header File For Windows
#include <gl\gl.h>						// Header File For The OpenGL32 Library
#include <gl\glu.h>						// Header File For The GLu32 Library
#include <gl\glaux.h>					// Header File For The GLaux Library

const static int maxWnds=16;

// WndProc function for all COpenGLWnd objects
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);

class COpenGLWnd 
{
	private:
		static int			 m_nWndCount;
		static COpenGLWnd	*m_WndList[maxWnds];

	protected:
		int			 m_WndPosInList;

		HINSTANCE	 m_hInstance;
		HWND		 m_hWnd;
		HDC			 m_hDC;				// Private GDI Device Context
		HGLRC		 m_hRC;             // Permanent Rendering Context
		char		*m_strCmdLine;

		bool		 m_bFullScreen;
		bool		 m_bActive;
		bool		 m_bKeys[512];
		int			 m_nWidth;			// Width of Wnd
		int			 m_nHeight;			// Height of Wnd
		char		 m_strTitle[255];
		float		 m_fFov;
		float		 m_fNear;
		float		 m_fFar;
		int			 m_nBits;

		virtual bool InitGL()=0;
	public:
		// class functions
		static void Initialize();
		static COpenGLWnd *FromHandlePermanent(HWND hWnd);
		
		// constructor & destructor
		COpenGLWnd(HINSTANCE hInstance, char *strCmdLine);
		virtual ~COpenGLWnd();
		
		// Main functions
		bool CreateGLWindow(char *strTitle, int nWidth, int nHeight, int nBits, bool bFullScreenFlag,
							float fFov=60, float fNear=1, float fFar=100);
		void KillGLWindow();
		void ResizeGLScene(int nWidth, int nHeight);
		
		bool GetFullScreen() const;
		void SetFullScreen(bool FullScreen);
		bool IsActive();
		
		HINSTANCE GethInstance() const;
		HDC GethDC() const;
		HGLRC GethRC() const;
		HWND GethWnd() const;
		
		// overridables
		virtual bool Init();				// all Inits you need
		virtual bool DeInit();  			// all DeInits you need
		virtual bool DrawGLScene(); 		// standard Drawing function
		virtual LRESULT WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam); // your Wnd proc
};

#endif;