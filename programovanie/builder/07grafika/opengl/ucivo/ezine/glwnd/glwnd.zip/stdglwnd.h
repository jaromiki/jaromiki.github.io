////////////////////////////////////////////////////////////////////////////////
//  File:   stdglwnd.h
//  Name:   CStdGLWnd Class (h)
//  Auhtor: Johny, johny@ammo.sk, www.ammo.sk
//  Date:   20.05.2003
////////////////////////////////////////////////////////////////////////////////

#ifndef STDGLWND_H
#define STDGLWND_H

#include "openglwnd.h"

class CStdGLWnd:public COpenGLWnd
{
	protected:
		virtual bool InitGL();
	public:
		CStdGLWnd(HINSTANCE hInstance, char *strCmdLine);
		virtual bool Init();
		virtual bool DeInit();
		virtual bool DrawGLScene();
		virtual LRESULT WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
};

#endif