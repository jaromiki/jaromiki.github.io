////////////////////////////////////////////////////////////////////////////////
//  File:   openglwnd.cpp
//  Name:   COpenGLWnd Class (cpp)
//  Auhtor: Johny, johny@ammo.sk, www.ammo.sk
//  Date:   20.05.2003
////////////////////////////////////////////////////////////////////////////////

#include "stdglwnd.h"

int			COpenGLWnd::m_nWndCount=0;
COpenGLWnd *COpenGLWnd::m_WndList[maxWnds];


// Heart of all WndProcs
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	COpenGLWnd* pOpenGLWnd = COpenGLWnd::FromHandlePermanent(hWnd);
	
	if (pOpenGLWnd!=NULL)				// message for our Wnd
	{
		if (pOpenGLWnd->WndProc(hWnd, nMsg, wParam, lParam)==0)
			return 0;					// don't want DefWindowProc
		else
			return DefWindowProc(hWnd, nMsg, wParam, lParam);
	}
	else		
		return DefWindowProc(hWnd, nMsg, wParam, lParam);
}

void COpenGLWnd::Initialize()
{
	int i;

	m_nWndCount=0;
	for (i=0;i<maxWnds;i++)
		m_WndList[i]=NULL;
}

COpenGLWnd *COpenGLWnd::FromHandlePermanent(HWND hWnd)
{
	COpenGLWnd *result=NULL;
	int i;

	for (i=0;i<m_nWndCount;i++)
	{
		if (m_WndList[i]!=NULL)
			if (m_WndList[i]->GethWnd()==hWnd) 
			{
				result=m_WndList[i];
			}
	}
	
	return result;
}

COpenGLWnd::COpenGLWnd(HINSTANCE hInstance, char *strCmdLine)
{
	int i;
	
	m_bFullScreen = true;
	m_hInstance  = hInstance;
	m_hDC        = NULL;					// Private GDI Device Context
	m_hRC        = NULL;					// Permanent Rendering Context
	m_hWnd       = NULL;
	m_strCmdLine=strCmdLine;

	m_WndPosInList=m_nWndCount;
	m_WndList[m_nWndCount]=this;
	m_nWndCount++;

	for (i=0;i<512;i++) m_bKeys[i]=false;
}

COpenGLWnd::~COpenGLWnd()
{
	m_WndList[m_WndPosInList]=NULL;
	DeInit();
	KillGLWindow();
}

bool COpenGLWnd::InitGL()
{
	return true;
}

bool COpenGLWnd::Init()
{
	return InitGL();
}

bool COpenGLWnd::DeInit()
{
	return true;
}

bool COpenGLWnd::DrawGLScene()
{
	return true;
}

LRESULT COpenGLWnd::WndProc(HWND   hWnd,    // Handle For This Window
                            UINT   Msg,    // Message For This Window
                            WPARAM wParam, // Additional Message Information
                            LPARAM lParam) // Additional Message Information
{
	return 1;
}

void COpenGLWnd::SetFullScreen(bool bFullScreen) 
{
	m_bFullScreen = bFullScreen;
}

bool COpenGLWnd::GetFullScreen() const 
{
	return m_bFullScreen;
}

bool COpenGLWnd::IsActive()
{
	return m_bActive;
}

HDC COpenGLWnd::GethDC() const 
{
	return m_hDC;
}

HWND COpenGLWnd::GethWnd() const 
{
	return m_hWnd;
}

HINSTANCE COpenGLWnd::GethInstance() const
{
	return m_hInstance;
}

HGLRC COpenGLWnd::GethRC() const
{
	return m_hRC;
}


bool COpenGLWnd::CreateGLWindow(char *strTitle, int nWidth, int nHeight, int nBits, bool bFullScreenFlag,
								float fFov, float fNear, float fFar)
{
	GLuint   PixelFormat;					// Holds The Results After Searching For A Match
	WNDCLASS wc;							// Windows Class Structure
	DWORD    dwExStyle;						// Window Extended Style
	DWORD    dwStyle;						// Window Style
	RECT     WindowRect;					// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left   = (long)0;			// Set Left Value To 0
	WindowRect.right  = (long)nWidth;		// Set Right Value To Requested Width
	WindowRect.top    = (long)0;			// Set Top Value To 0
	WindowRect.bottom = (long)nHeight;		// Set Bottom Value To Requested Height

	m_nWidth=nWidth;
	m_nHeight=nHeight;
	m_nBits=nBits;
	m_bFullScreen=bFullScreenFlag;
	m_fFov=fFov;
	m_fNear=fNear;
	m_fFar=fFar;
	strcpy(m_strTitle,strTitle);

	m_hInstance      = GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc   = MainWndProc;							// WndProc Handles Messages
	wc.cbClsExtra    = 0;									// No Extra Window Data
	wc.cbWndExtra    = 0;									// No Extra Window Data
	wc.hInstance     = m_hInstance;							// Set The Instance
	wc.hIcon         = LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor       = LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground = NULL;								// No Background Required For GL
	wc.lpszMenuName  = NULL;								// We Don't Want A Menu
	wc.lpszClassName = "OpenGL";							// Set The Class Name

															// Attempt To Register The Window Class
	if (!RegisterClass(&wc)) 
	{
		MessageBox(NULL, "Failed To Register The Window Class.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return false;
	}
	
	// Attempt Fullscreen Mode?
	if (m_bFullScreen) 
	{
		DEVMODE dmScreenSettings;                                 // Device Mode
		memset(&dmScreenSettings, 0, sizeof(dmScreenSettings));   // Makes Sure Memory's Cleared
		dmScreenSettings.dmSize       = sizeof(dmScreenSettings); // Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth  = m_nWidth;                    // Selected Screen Width
		dmScreenSettings.dmPelsHeight = m_nHeight;                   // Selected Screen Height
		dmScreenSettings.dmBitsPerPel = m_nBits;                     // Selected Bits Per Pixel
		dmScreenSettings.dmFields     = DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;
	
										// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL) 
		{
										// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL, "The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?",
						   "NeHe GL", MB_YESNO | MB_ICONEXCLAMATION) == IDYES) 
			{
				m_bFullScreen = false;		// Windowed Mode Selected.  Fullscreen = false
			}
			else 
			{
										// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL, "Program Will Now Close.", "ERROR", MB_OK | MB_ICONSTOP);
				return false;
			}
		}
	}

	// Are We Still In Fullscreen Mode?
	if (m_bFullScreen) 
	{
		dwExStyle = WS_EX_APPWINDOW;		// Window Extended Style
		dwStyle   = WS_POPUP;				// Windows Style
		ShowCursor(false);				// Hide Mouse Pointer

	}
	else 
	{
		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE; // Window Extended Style
		dwStyle   = WS_OVERLAPPEDWINDOW;                // Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, false, dwExStyle); // Adjust Window To true Requested Size

																	// Create The Window
	if (!(m_hWnd = CreateWindowEx(dwExStyle,						// Extended Style For The Window
								  "OpenGL",                         // Class Name
                                  strTitle,                         // Window Title
                                  dwStyle |                         // Defined Window Style
                                  WS_CLIPSIBLINGS |                 // Required Window Style
                                  WS_CLIPCHILDREN,                  // Required Window Style
                                  0, 0,                             // Window Position
                                  WindowRect.right-WindowRect.left, // Calculate Window Width
                                  WindowRect.bottom-WindowRect.top, // Calculate Window Height
                                  NULL,                             // No Parent Window
                                  NULL,                             // No Menu
                                  m_hInstance,                      // Instance
                                  NULL)))                           // Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();					// Reset The Display
		MessageBox(NULL, "Window Creation Error.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return false;
	}


										// pfd Tells Windows How We Want Things To Be
	static PIXELFORMATDESCRIPTOR pfd = 
	{
		sizeof(PIXELFORMATDESCRIPTOR), // Size Of This Pixel Format Descriptor
		1,                             // Version Number
		PFD_DRAW_TO_WINDOW |           // Format Must Support Window
		PFD_SUPPORT_OPENGL |           // Format Must Support OpenGL
		PFD_DOUBLEBUFFER,              // Must Support Double Buffering
		PFD_TYPE_RGBA,                 // Request An RGBA Format
		m_nBits,                       // Select Our Color Depth
		0, 0, 0, 0, 0, 0,              // Color Bits Ignored
		0,                             // No Alpha Buffer
		0,                             // Shift Bit Ignored
		0,                             // No Accumulation Buffer
		0, 0, 0, 0,                    // Accumulation Bits Ignored
		16,                            // 16Bit Z-Buffer (Depth Buffer)
		0,                             // No Stencil Buffer
		0,                             // No Auxiliary Buffer
		PFD_MAIN_PLANE,                // Main Drawing Layer
		0,                             // Reserved
		0, 0, 0                        // Layer Masks Ignored
	};

	// Did We Get A Device Context?
	if (!(m_hDC = GetDC(m_hWnd))) 
	{
		KillGLWindow(); // Reset The Display
		MessageBox(NULL, "Can't Create A GL Device Context.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return false; // Return false
	}

	// Did Windows Find A Matching Pixel Format?
	if (!(PixelFormat = ChoosePixelFormat(m_hDC, &pfd))) 
	{
		KillGLWindow(); // Reset The Display
		MessageBox(NULL, "Can't Find A Suitable PixelFormat.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return false; // Return false
	}

	// Are We Able To Set The Pixel Format?
	if(!SetPixelFormat(m_hDC, PixelFormat, &pfd)) 
	{
		KillGLWindow(); // Reset The Display
		MessageBox(NULL, "Can't Set The PixelFormat.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
	    return false; // Return false
	}

	// Are We Able To Get A Rendering Context?
	if (!(m_hRC=wglCreateContext(m_hDC))) 
	{
		KillGLWindow(); // Reset The Display
		MessageBox(NULL, "Can't Create A GL Rendering Context.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return false; // Return false
	}

	// Try To Activate The Rendering Context
	if(!wglMakeCurrent(m_hDC, m_hRC)) 
	{
		KillGLWindow(); // Reset The Display
		MessageBox(NULL, "Can't Activate The GL Rendering Context.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return false; // Return false
	}

	ShowWindow(m_hWnd, SW_SHOW);    // Show The Window
	SetForegroundWindow(m_hWnd);    // Slightly Higher Priority
	SetFocus(m_hWnd);               // Sets Keyboard Focus To The Window
	
	m_bActive=true;
	ResizeGLScene(m_nWidth, m_nHeight); // Set Up Our Perspective GL Screen

	return true; // Success
}

void COpenGLWnd::ResizeGLScene(int nWidth, int nHeight)		
{
	if (nHeight==0) nHeight=1;
	
	glViewport(0,0,nWidth,nHeight);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(m_fFov,float(nWidth)/float(nHeight),m_fNear,m_fFar);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void COpenGLWnd::KillGLWindow() 
{
	// Are We In Fullscreen Mode?
	m_bActive=false;
	if (m_bFullScreen) 
	{
		ChangeDisplaySettings(NULL, 0); // If So Switch Back To The Desktop
		ShowCursor(true);              // Show Mouse Pointer
	}

	// Do We Have A Rendering Context?
	if (m_hRC) 
	{
		// Are We Able To Release The DC And RC Contexts?
		if (!wglMakeCurrent(NULL, NULL)) 
		{
			MessageBox(NULL, "Release Of DC And RC Failed.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		}

		// Are We Able To Delete The RC?
		if (!wglDeleteContext(m_hRC)) 
		{
			MessageBox(NULL, "Release Rendering Context Failed.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		}

		m_hRC = NULL; // Set RC To NULL
	}

	// Are We Able To Release The DC
	if (m_hDC && !ReleaseDC(m_hWnd, m_hDC)) 
	{
		MessageBox(NULL, "Release Device Context Failed.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		m_hDC = NULL; // Set DC To NULL
	}

	// Are We Able To Destroy The Window?
	if (m_hWnd && !DestroyWindow(m_hWnd)) 
	{
		MessageBox(NULL, "Could Not Release hWnd.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		m_hWnd = NULL; // Set hWnd To NULL
	}

	// Are We Able To Unregister Class
	if (!UnregisterClass("OpenGL", m_hInstance)) 
	{
		MessageBox(NULL, "Could Not Unregister Class.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		m_hInstance = NULL; // Set hInstance To NULL
	}
}