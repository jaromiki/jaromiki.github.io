////////////////////////////////////////////////////////////////////////////////
//  File:   main.cpp
//  Name:   WinMain Loop
//  Auhtor: Johny, johny@ammo.sk, www.ammo.sk
//  Date:   20.05.2003
////////////////////////////////////////////////////////////////////////////////

#include "examplewnd.h"


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
																	// Don't forget !!!
	COpenGLWnd::Initialize();										// We must initialize COpenGLWnd class
																	// Don't forget !!!

	CExampleWnd *pGLApp = new CExampleWnd(hInstance, lpCmdLine);	// Create 1 ExampleWnd
   
	MSG				msg;
	int				nGotMsg=false;
	bool			bDone = false;
	const int		nWidth=640;
	const int		nHeight=480;
	const int		nBits=16;

	if ( MessageBox(NULL, "Would You Like To Run In Fullscreen Mode?",		// fullscreen ?
					"Start FullScreen?", MB_YESNO|MB_ICONQUESTION
				   ) == IDNO	
	   ) 
		pGLApp->SetFullScreen(false);
	
	// Creating our Window
	if ( pGLApp->CreateGLWindow("OpenGL Framework", nWidth, nHeight, nBits, pGLApp->GetFullScreen()) )
	{
		if ( !pGLApp->Init() )	// Init all we need
		{
			MessageBox(NULL, "Initialization Failed.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
			delete pGLApp;
			return 0;
		}
	}
	else
	{
		MessageBox(NULL, "OpenGL Initialization Failed.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		delete pGLApp;
		return 0;
	}
		
	while (!bDone) 
	{
		// If our Wnd is not active we don't waste system resources
		// without this checking we use 100% of CPU time only with PeekMessage,
		// try to do it, if you don't trust me
		if (pGLApp->IsActive())
			nGotMsg = PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);
		else 
			nGotMsg = GetMessage(&msg, NULL, 0, 0);

		if (nGotMsg==0)					// no message, let's draw
		{	
			if (pGLApp->IsActive())		// draw only if active
				if (pGLApp->DrawGLScene()) SwapBuffers( pGLApp->GethDC() );
		}
		else
		{
			if (msg.message==WM_QUIT) bDone=true;
			else
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
	}

	delete pGLApp;			// DeInit is called in destructor
	return(msg.wParam);
}