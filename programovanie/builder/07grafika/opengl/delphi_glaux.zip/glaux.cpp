
#include <windows.h>


int FAR PASCAL LibMain (HINSTANCE, WORD, WORD, LPSTR)
{
  return 1;
}



