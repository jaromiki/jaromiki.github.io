//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <gl\gl.h>// Hlavi�kov� soubor pro OpenGL32 knihovnu
#include <gl\glu.h>// Hlavi�kov� soubor pro Glu32 knihovnu
#include <gl\glaux.h>// Hlavi�kov� soubor pro Glaux knihovnu

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{    ogl_inicialized=0;
     ogl_init();
}
void TForm1::ogl_draw()
{ glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
//tu zad�vame pr�kazy na kreslenie
  glColor4f(1.0f, 1.0f, 1.0f,1.0f);
  glBegin(GL_LINES);
  glVertex3i(0,0,0);glVertex3i(7,0,0);
  glVertex3i(0,0,0);glVertex3i(0,7,0);
  glVertex3i(0,0,0);glVertex3i(0,0,7);
   glEnd();
glFlush();
SwapBuffers(hdc);

}

//---------------------------------------------------------------------------

void __fastcall TForm1::destroy(TObject *Sender)
{
  ogl_exit();        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::resize(TObject *Sender)
{
ogl_resize();
}
//---------------------------------------------------------------------------
