//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
int a[20],b[20],i,j;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{  Image1->Canvas->Brush->Color = clWhite;
   Image1->Canvas->FillRect(Image1->ClientRect);
   Image1->Canvas->Brush->Color = clBlue;
   for (i=0;i<10;i++) {a[i]=random(60)*5; b[i]=(random(2)?+5:-5);}
   for (i=0;i<10;i++) Image1->Canvas->Rectangle(i*40,400,i*40+35,a[i]);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{  Image1->Canvas->Brush->Color = clWhite;
   Image1->Canvas->FillRect(Image1->ClientRect);
   Image1->Canvas->Brush->Color = clBlue;
   for (i=0;i<10;i++)
   {a[i]+=b[i]; if (a[i]<5 || a[i]>395) b[i]*=-1;
     Image1->Canvas->Rectangle(i*40,400,i*40+35,a[i]);
   }
}
//---------------------------------------------------------------------------
